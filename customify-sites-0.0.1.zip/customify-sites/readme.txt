=== Customify Sites ===
Contributors: WPCustomify
Tags: demo, theme demos, one click import
Requires at least: 4.9.5
Tested up to: 4.9.5

Import free sites build with Customify theme.

== Description ==
This plugin is an add-on for the Customify WordPress Theme. It offers a library of ready sites that can be imported for your website easily. Here is how it works:

1. Browse through the library of ready sites right from your WordPress backend.
2. Pick a site you like.
3. Install required plugins in one click
4. Import the site data.
5. Done ;)

Use this imported site as a base for your project and don't waste time starting from scratch!


== Installation ==
1. Upload the plugin files to the `/wp-content/plugins/` directory, or install the plugin through the WordPress plugins screen directly.
2. Activate the plugin through the `Plugins` screen in WordPress
3. Use the Appearance->Customify Sites to choice demo import.

== Changelog ==
v0.0.1
* Initial.